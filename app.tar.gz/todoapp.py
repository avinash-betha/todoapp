import flet as ft

def main(page: ft.Page):
    # Setting up the page title and navigation bar
    page.title = "To-do App"

    # Define a function to handle theme switching
    def toggle_theme(e):
        if theme_switch.value:
            page.theme_mode = ft.ThemeMode.DARK
        else:
            page.theme_mode = ft.ThemeMode.LIGHT
        page.update()

    # Create a switch for theme toggling
    theme_switch = ft.Switch(label="Dark Mode", on_change=toggle_theme)

    # Create a navigation bar with title and theme switch
    nav_bar = ft.AppBar(
        title=ft.Text("To-do App"),
        actions=[theme_switch]
    )

    # Set the navigation bar to the page
    page.appbar = nav_bar

    # Taking input from the user
    input_text = ft.TextField(hint_text="Record Task todo...", width=350)

    def button_clicked(e):
        if input_text.value == "":
            print("No task is recorded!")
            # Display a snackbar message
            page.snack_bar = ft.SnackBar(
                content=ft.Text("No task is recorded!"),
                duration=2000
            )
            page.snack_bar.open = True
        else:
            # Add the task to the list as a checkbox
            page.add(ft.Checkbox(label=input_text.value))
            # Clear the text field
            input_text.value = ""
        # Update the page to reflect changes
        page.update()

    # Aligning the input text and button in a row
    page.add(
        ft.Row(
            [
                input_text,
                ft.ElevatedButton(text="Add", on_click=button_clicked)
            ]
        )
    )

ft.app(target=main, view=ft.WEB_BROWSER)
